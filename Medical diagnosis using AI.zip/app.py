import streamlit as st
import pickle
from streamlit_option_menu import option_menu

# Change Name & Logo
st.set_page_config(page_title="Disease Prediction", page_icon="⚕️")

# Hiding Streamlit add-ons
hide_st_style = """
            <style>
            #MainMenu {visibility: hidden;}
            footer {visibility: hidden;}
            header {visibility: hidden;}
            </style>
            """
st.markdown(hide_st_style, unsafe_allow_html=True)

# Adding Background Image
background_image_url = "https://wallpapers.com/images/hd/hd-medical-health-icon-with-stethoscope-zwpo6s3pg7xqndlk.jpg"  # Replace with your image URL

page_bg_img = f"""
<style>
[data-testid="stAppViewContainer"] {{
background-image: url({background_image_url});
background-size: cover;
background-position: center;
background-repeat: no-repeat;
background-attachment: fixed;
}}

[data-testid="stAppViewContainer"]::before {{
content: "";
position: absolute;
top: 0;
left: 0;
width: 100%;
height: 100%;
background-color: rgba(0, 0, 0, 0.7);
}}
</style>
"""
# st.markdown(page_bg_img,"<h2 style='color:#FFD700;'>Select a Disease to Predict</h2>", unsafe_allow_html=True)
# Set background image
st.markdown(page_bg_img, unsafe_allow_html=True)
# Display the heading with custom styling
st.markdown("<h2 style='color:#FFD700;'>Select a Disease to Predict</h2>", unsafe_allow_html=True)

# Load the saved models
models = {
    'diabetes': pickle.load(open('Models/diabetes_model.sav', 'rb')),
    'heart_disease': pickle.load(open('Models/heart_disease_model.sav', 'rb')),
    'parkinsons': pickle.load(open('Models/parkinsons_model.sav', 'rb')),
    'lung_cancer': pickle.load(open('Models/lungs_disease_model.sav', 'rb')),
    'thyroid': pickle.load(open('Models/Thyroid_model.sav', 'rb'))
}

# Create a dropdown menu for disease prediction
selected = st.selectbox(
    'Select a Disease to Predict',
    ['Diabetes Prediction',
     'Heart Disease Prediction',
     'Parkinsons Prediction',
     'Lung Cancer Prediction',
     'Hypo-Thyroid Prediction']
)

def display_input(label, tooltip, key, type="text"):
    if type == "text":
        return st.text_input(label, key=key, help=tooltip)
    elif type == "number":
        return st.number_input(label, key=key, help=tooltip, step=1)

# Diabetes Prediction Page
if selected == 'Diabetes Prediction':
    # st.title('Diabetes')
    # st.write("Enter the following details to predict diabetes:")
    st.markdown("<h1 style='color:#00FF00;'>Diabetes</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='color:#FFFFFF;'>Enter the following details to predict diabetes:</h3>", unsafe_allow_html=True)

    # Pregnancies = display_input('<span style="color:#87CEEB;">Number of Pregnancies</span>', 'Enter number of times pregnant', 'Pregnancies', 'number')
    # Glucose = display_input('<span style="color:#87CEEB;">Glucose Level</span>', 'Enter glucose level', 'Glucose', 'number')
    # BloodPressure = display_input('<span style="color:#87CEEB;">Blood Pressure value</span>', 'Enter blood pressure value', 'BloodPressure', 'number')
    # SkinThickness = display_input('<span style="color:#87CEEB;">Skin Thickness value</span>', 'Enter skin thickness value', 'SkinThickness', 'number')
    # Insulin = display_input('<span style="color:#87CEEB;">INsulin Level</span>', 'Enter insulin level', 'Insulin', 'number')
    # BMI = display_input('<span style="color:#87CEEB;">BMI Value</span>', 'Enter Body Mass Index value', 'BMI', 'number')
    # DiabetesPedigreeFunction = display_input('<span style="color:#87CEEB;">Diabetes Pedigree Function value</span>', 'Enter diabetes pedigree function value', 'DiabetesPedigreeFunction', 'number')
    # Age = display_input('<span style="color:#87CEEB;">Age of the Person</span>', 'Enter age of the person', 'Age', 'number')

    # Use st.markdown for labels and store input separately
    st.markdown("<p style='color:#87CEEB;'>Number of Pregnancies</p>", unsafe_allow_html=True)
    Pregnancies = st.number_input(' ', key='Pregnancies', step=1)

    st.markdown("<p style='color:#87CEEB;'>Glucose Level</p>", unsafe_allow_html=True)
    Glucose = st.number_input(' ', key='Glucose', step=1)

    st.markdown("<p style='color:#87CEEB;'>Blood Pressure value</p>", unsafe_allow_html=True)
    BloodPressure = st.number_input(' ', key='BloodPressure', step=1)

    st.markdown("<p style='color:#87CEEB;'>Skin Thickness value</p>", unsafe_allow_html=True)
    SkinThickness = st.number_input(' ', key='SkinThickness', step=1)

    st.markdown("<p style='color:#87CEEB;'>Insulin Level</p>", unsafe_allow_html=True)
    Insulin = st.number_input(' ', key='Insulin', step=1)

    st.markdown("<p style='color:#87CEEB;'>BMI value</p>", unsafe_allow_html=True)
    BMI = st.number_input(' ', key='BMI', step=1)

    st.markdown("<p style='color:#87CEEB;'>Diabetes Pedigree Function value</p>", unsafe_allow_html=True)
    DiabetesPedigreeFunction = st.number_input(' ', key='DiabetesPedigreeFunction', step=1)

    st.markdown("<p style='color:#87CEEB;'>Age of the Person</p>", unsafe_allow_html=True)
    Age = st.number_input(' ', key='Age', step=1)

    diab_diagnosis = ''
    if st.button('Diabetes Test Result'):
        diab_prediction = models['diabetes'].predict([[Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin, BMI, DiabetesPedigreeFunction, Age]])
        diab_diagnosis = 'The person is diabetic' if diab_prediction[0] == 1 else 'The person is not diabetic'
        st.success(diab_diagnosis)

# Heart Disease Prediction Page
if selected == 'Heart Disease Prediction':
    # st.title('Heart Disease')
    # st.write("Enter the following details to predict heart disease:")

    # age = display_input('Age', 'Enter age of the person', 'age', 'number')
    # sex = display_input('Sex (1 = male; 0 = female)', 'Enter sex of the person', 'sex', 'number')
    # cp = display_input('Chest Pain types (0, 1, 2, 3)', 'Enter chest pain type', 'cp', 'number')
    # trestbps = display_input('Resting Blood Pressure', 'Enter resting blood pressure', 'trestbps', 'number')
    # chol = display_input('Serum Cholesterol in mg/dl', 'Enter serum cholesterol', 'chol', 'number')
    # fbs = display_input('Fasting Blood Sugar > 120 mg/dl (1 = true; 0 = false)', 'Enter fasting blood sugar', 'fbs', 'number')
    # restecg = display_input('Resting Electrocardiographic results (0, 1, 2)', 'Enter resting ECG results', 'restecg', 'number')
    # thalach = display_input('Maximum Heart Rate achieved', 'Enter maximum heart rate', 'thalach', 'number')
    # exang = display_input('Exercise Induced Angina (1 = yes; 0 = no)', 'Enter exercise induced angina', 'exang', 'number')
    # oldpeak = display_input('ST depression induced by exercise', 'Enter ST depression value', 'oldpeak', 'number')
    # slope = display_input('Slope of the peak exercise ST segment (0, 1, 2)', 'Enter slope value', 'slope', 'number')
    # ca = display_input('Major vessels colored by fluoroscopy (0-3)', 'Enter number of major vessels', 'ca', 'number')
    # thal = display_input('Thal (0 = normal; 1 = fixed defect; 2 = reversible defect)', 'Enter thal value', 'thal', 'number')

    st.markdown("<h1 style='color:#00FF00;'>Heart Disease</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='color:#FFFFFF;'>Enter the following details to predict heart disease:</h3>", unsafe_allow_html=True)

    st.markdown("<p style='color:#87CEEB;'>Age</p>", unsafe_allow_html=True)
    age = st.number_input(' ', key='age', step=1)

    st.markdown("<p style='color:#87CEEB;'>Sex (1 = Male, 0 = Female)</p>", unsafe_allow_html=True)
    sex = st.number_input(' ', key='sex', step=1)

    st.markdown("<p style='color:#87CEEB;'>Chest Pain types (0-3)</p>", unsafe_allow_html=True)
    cp = st.number_input(' ', key='cp', step=1)

    st.markdown("<p style='color:#87CEEB;'>Resting Blood Pressure</p>", unsafe_allow_html=True)
    trestbps = st.number_input(' ', key='trestbps', step=1)

    st.markdown("<p style='color:#87CEEB;'>Serum Cholesterol in mg/dl</p>", unsafe_allow_html=True)
    chol = st.number_input(' ', key='chol', step=1)

    st.markdown("<p style='color:#87CEEB;'>Fasting Blood Sugar > 120 mg/dl (1 = true; 0 = false)</p>", unsafe_allow_html=True)
    fbs = st.number_input(' ', key='fbs', step=1)

    st.markdown("<p style='color:#87CEEB;'>Resting Electrocardiographic results (0, 1, 2)</p>", unsafe_allow_html=True)
    restecg = st.number_input(' ', key='restecg', step=1)

    st.markdown("<p style='color:#87CEEB;'>Maximum Heart Rate achieved</p>", unsafe_allow_html=True)
    thalach = st.number_input(' ', key='thalach', step=1)

    st.markdown("<p style='color:#87CEEB;'>Exercise Induced Angina (1 = yes; 0 = no)</p>", unsafe_allow_html=True)
    exang = st.number_input(' ', key='exang', step=1)

    st.markdown("<p style='color:#87CEEB;'>ST depression induced by exercise</p>", unsafe_allow_html=True)
    oldpeak = st.number_input(' ', key='oldpeak', step=1)

    st.markdown("<p style='color:#87CEEB;'>Slope of the peak exercise ST segment (0, 1, 2)</p>", unsafe_allow_html=True)
    slope = st.number_input(' ', key='slope', step=1)

    st.markdown("<p style='color:#87CEEB;'>Number of major vessels (0-3) colored by fluoroscopy</p>", unsafe_allow_html=True)
    ca = st.number_input(' ', key='ca', step=1)

    st.markdown("<p style='color:#87CEEB;'>Thal (0 = normal; 1 = fixed defect; 2 = reversible defect)</p>", unsafe_allow_html=True)
    thal = st.number_input(' ', key='thal', step=1)

    heart_diagnosis = ''
    if st.button('Heart Disease Test Result'):
        heart_prediction = models['heart_disease'].predict([[age, sex, cp, trestbps, chol, fbs, restecg, thalach, exang, oldpeak, slope, ca, thal]])
        heart_diagnosis = 'The person has heart disease' if heart_prediction[0] == 1 else 'The person does not have heart disease'
        st.success(heart_diagnosis)

# Parkinson's Prediction Page
if selected == "Parkinsons Prediction":
    # st.title("Parkinson's Disease")
    # st.write("Enter the following details to predict Parkinson's disease:")

    # fo = display_input('MDVP:Fo(Hz)', 'Enter MDVP:Fo(Hz) value', 'fo', 'number')
    # fhi = display_input('MDVP:Fhi(Hz)', 'Enter MDVP:Fhi(Hz) value', 'fhi', 'number')
    # flo = display_input('MDVP:Flo(Hz)', 'Enter MDVP:Flo(Hz) value', 'flo', 'number')
    # Jitter_percent = display_input('MDVP:Jitter(%)', 'Enter MDVP:Jitter(%) value', 'Jitter_percent', 'number')
    # Jitter_Abs = display_input('MDVP:Jitter(Abs)', 'Enter MDVP:Jitter(Abs) value', 'Jitter_Abs', 'number')
    # RAP = display_input('MDVP:RAP', 'Enter MDVP:RAP value', 'RAP', 'number')
    # PPQ = display_input('MDVP:PPQ', 'Enter MDVP:PPQ value', 'PPQ', 'number')
    # DDP = display_input('Jitter:DDP', 'Enter Jitter:DDP value', 'DDP', 'number')
    # Shimmer = display_input('MDVP:Shimmer', 'Enter MDVP:Shimmer value', 'Shimmer', 'number')
    # Shimmer_dB = display_input('MDVP:Shimmer(dB)', 'Enter MDVP:Shimmer(dB) value', 'Shimmer_dB', 'number')
    # APQ3 = display_input('Shimmer:APQ3', 'Enter Shimmer:APQ3 value', 'APQ3', 'number')
    # APQ5 = display_input('Shimmer:APQ5', 'Enter Shimmer:APQ5 value', 'APQ5', 'number')
    # APQ = display_input('MDVP:APQ', 'Enter MDVP:APQ value', 'APQ', 'number')
    # DDA = display_input('Shimmer:DDA', 'Enter Shimmer:DDA value', 'DDA', 'number')
    # NHR = display_input('NHR', 'Enter NHR value', 'NHR', 'number')
    # HNR = display_input('HNR', 'Enter HNR value', 'HNR', 'number')
    # RPDE = display_input('RPDE', 'Enter RPDE value', 'RPDE', 'number')
    # DFA = display_input('DFA', 'Enter DFA value', 'DFA', 'number')
    # spread1 = display_input('Spread1', 'Enter spread1 value', 'spread1', 'number')
    # spread2 = display_input('Spread2', 'Enter spread2 value', 'spread2', 'number')
    # D2 = display_input('D2', 'Enter D2 value', 'D2', 'number')
    # PPE = display_input('PPE', 'Enter PPE value', 'PPE', 'number')

    st.markdown("<h1 style='color:#00FF00;'>Parkinson's Disease</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='color:#FFFFFF;'>Enter the following details to predict Parkinson's disease:</h3>", unsafe_allow_html=True)

    features = ['fo', 'fhi', 'flo', 'jitter_percent', 'jitter_abs', 'rap', 'ppq', 'ddp', 'shimmer', 'shimmer_db', 'apq3', 'apq5', 'apq', 'dda', 'nhr', 'hnr', 'rpde', 'dfa', 'spread1', 'spread2', 'd2', 'ppe']
    inputs = []
    
    for feature in features:
        st.markdown(f"<p style='color:#87CEEB;'>{feature.replace('_', ' ').title()}</p>", unsafe_allow_html=True)
        value = st.number_input(' ', key=feature, step=1.0)
        inputs.append(value)
        
    parkinsons_diagnosis = ''
    if st.button("Parkinson's Test Result"):
        parkinsons_prediction = models['parkinsons'].predict([[fo, fhi, flo, Jitter_percent, Jitter_Abs, RAP, PPQ, DDP, Shimmer, Shimmer_dB, APQ3, APQ5, APQ, DDA, NHR, HNR, RPDE, DFA, spread1, spread2, D2, PPE]])
        parkinsons_diagnosis = "The person has Parkinson's disease" if parkinsons_prediction[0] == 1 else "The person does not have Parkinson's disease"
        st.success(parkinsons_diagnosis)

# Lung Cancer Prediction Page
if selected == "Lung Cancer Prediction":
    # st.title("Lung Cancer")
    # st.write("Enter the following details to predict lung cancer:")

    # GENDER = display_input('Gender (1 = Male; 0 = Female)', 'Enter gender of the person', 'GENDER', 'number')
    # AGE = display_input('Age', 'Enter age of the person', 'AGE', 'number')
    # SMOKING = display_input('Smoking (1 = Yes; 0 = No)', 'Enter if the person smokes', 'SMOKING', 'number')
    # YELLOW_FINGERS = display_input('Yellow Fingers (1 = Yes; 0 = No)', 'Enter if the person has yellow fingers', 'YELLOW_FINGERS', 'number')
    # ANXIETY = display_input('Anxiety (1 = Yes; 0 = No)', 'Enter if the person has anxiety', 'ANXIETY', 'number')
    # PEER_PRESSURE = display_input('Peer Pressure (1 = Yes; 0 = No)', 'Enter if the person is under peer pressure', 'PEER_PRESSURE', 'number')
    # CHRONIC_DISEASE = display_input('Chronic Disease (1 = Yes; 0 = No)', 'Enter if the person has a chronic disease', 'CHRONIC_DISEASE', 'number')
    # FATIGUE = display_input('Fatigue (1 = Yes; 0 = No)', 'Enter if the person experiences fatigue', 'FATIGUE', 'number')
    # ALLERGY = display_input('Allergy (1 = Yes; 0 = No)', 'Enter if the person has allergies', 'ALLERGY', 'number')
    # WHEEZING = display_input('Wheezing (1 = Yes; 0 = No)', 'Enter if the person experiences wheezing', 'WHEEZING', 'number')
    # ALCOHOL_CONSUMING = display_input('Alcohol Consuming (1 = Yes; 0 = No)', 'Enter if the person consumes alcohol', 'ALCOHOL_CONSUMING', 'number')
    # COUGHING = display_input('Coughing (1 = Yes; 0 = No)', 'Enter if the person experiences coughing', 'COUGHING', 'number')
    # SHORTNESS_OF_BREATH = display_input('Shortness Of Breath (1 = Yes; 0 = No)', 'Enter if the person experiences shortness of breath', 'SHORTNESS_OF_BREATH', 'number')
    # SWALLOWING_DIFFICULTY = display_input('Swallowing Difficulty (1 = Yes; 0 = No)', 'Enter if the person has difficulty swallowing', 'SWALLOWING_DIFFICULTY', 'number')
    # CHEST_PAIN = display_input('Chest Pain (1 = Yes; 0 = No)', 'Enter if the person experiences chest pain', 'CHEST_PAIN', 'number')

    st.markdown("<h1 style='color:#00FF00;'>Lung Cancer</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='color:#FFFFFF;'>Enter the following details to predict lung cancer:</h3>", unsafe_allow_html=True)

    st.markdown("<p style='color:#87CEEB;'>Gender (1 = Male, 0 = Female)</p>", unsafe_allow_html=True)
    gender = st.number_input(' ', key='gender', step=1)

    st.markdown("<p style='color:#87CEEB;'>Age</p>", unsafe_allow_html=True)
    age = st.number_input(' ', key='lung_age', step=1)

    st.markdown("<p style='color:#87CEEB;'>Smoking (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    smoking = st.number_input(' ', key='smoking', step=1)

    st.markdown("<p style='color:#87CEEB;'>Yellow Fingers (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    yellow_fingers = st.number_input(' ', key='yellow_fingers', step=1)

    st.markdown("<p style='color:#87CEEB;'>Anxiety (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    anxiety = st.number_input(' ', key='anxiety', step=1)

    st.markdown("<p style='color:#87CEEB;'>Peer Pressure (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    peer_pressure = st.number_input(' ', key='peer_pressure', step=1)

    st.markdown("<p style='color:#87CEEB;'>Chronic Disease (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    chronic_disease = st.number_input(' ', key='chronic_disease', step=1)

    st.markdown("<p style='color:#87CEEB;'>Fatigue (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    fatigue = st.number_input(' ', key='fatigue', step=1)

    st.markdown("<p style='color:#87CEEB;'>Allergy (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    allergy = st.number_input(' ', key='allergy', step=1)

    st.markdown("<p style='color:#87CEEB;'>Wheezing (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    wheezing = st.number_input(' ', key='wheezing', step=1)

    st.markdown("<p style='color:#87CEEB;'>Alcohol Consuming (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    alcohol_consuming = st.number_input(' ', key='alcohol_consuming', step=1)

    st.markdown("<p style='color:#87CEEB;'>Coughing (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    coughing = st.number_input(' ', key='coughing', step=1)

    st.markdown("<p style='color:#87CEEB;'>Shortness of Breath (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    shortness_of_breath = st.number_input(' ', key='shortness_of_breath', step=1)

    st.markdown("<p style='color:#87CEEB;'>Swallowing Difficulty (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    swallowing_difficulty = st.number_input(' ', key='swallowing_difficulty', step=1)

    st.markdown("<p style='color:#87CEEB;'>Chest Pain (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    chest_pain = st.number_input(' ', key='chest_pain', step=1)

    lungs_diagnosis = ''
    if st.button("Lung Cancer Test Result"):
        lungs_prediction = models['lung_cancer'].predict([[GENDER, AGE, SMOKING, YELLOW_FINGERS, ANXIETY, PEER_PRESSURE, CHRONIC_DISEASE, FATIGUE, ALLERGY, WHEEZING, ALCOHOL_CONSUMING, COUGHING, SHORTNESS_OF_BREATH, SWALLOWING_DIFFICULTY, CHEST_PAIN]])
        lungs_diagnosis = "The person has lung cancer disease" if lungs_prediction[0] == 1 else "The person does not have lung cancer disease"
        st.success(lungs_diagnosis)

# Hypo-Thyroid Prediction Page
if selected == "Hypo-Thyroid Prediction":
    # st.title("Hypo-Thyroid")
    # st.write("Enter the following details to predict hypo-thyroid disease:")

    # age = display_input('Age', 'Enter age of the person', 'age', 'number')
    # sex = display_input('Sex (1 = Male; 0 = Female)', 'Enter sex of the person', 'sex', 'number')
    # on_thyroxine = display_input('On Thyroxine (1 = Yes; 0 = No)', 'Enter if the person is on thyroxine', 'on_thyroxine', 'number')
    # tsh = display_input('TSH Level', 'Enter TSH level', 'tsh', 'number')
    # t3_measured = display_input('T3 Measured (1 = Yes; 0 = No)', 'Enter if T3 was measured', 't3_measured', 'number')
    # t3 = display_input('T3 Level', 'Enter T3 level', 't3', 'number')
    # tt4 = display_input('TT4 Level', 'Enter TT4 level', 'tt4', 'number')
    
    st.markdown("<h1 style='color:#00FF00;'>Hypo-Thyroid</h1>", unsafe_allow_html=True)
    st.markdown("<h3 style='color:#FFFFFF;'>Enter the following details to predict hypo-thyroid disease:</h3>", unsafe_allow_html=True)

    st.markdown("<p style='color:#87CEEB;'>Age</p>", unsafe_allow_html=True)
    age = st.number_input(' ', key='thyroid_age', step=1)

    st.markdown("<p style='color:#87CEEB;'>Sex (1 = Male, 0 = Female)</p>", unsafe_allow_html=True)
    sex = st.number_input(' ', key='thyroid_sex', step=1)

    st.markdown("<p style='color:#87CEEB;'>On Thyroxine (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    on_thyroxine = st.number_input(' ', key='on_thyroxine', step=1)

    st.markdown("<p style='color:#87CEEB;'>TSH Level</p>", unsafe_allow_html=True)
    tsh = st.number_input(' ', key='tsh', step=1)

    st.markdown("<p style='color:#87CEEB;'>T3 Measured (1 = Yes, 0 = No)</p>", unsafe_allow_html=True)
    t3_measured = st.number_input(' ', key='t3_measured', step=1)

    st.markdown("<p style='color:#87CEEB;'>T3 Level</p>", unsafe_allow_html=True)
    t3 = st.number_input(' ', key='t3', step=1)

    st.markdown("<p style='color:#87CEEB;'>TT4 Level</p>", unsafe_allow_html=True)
    tt4 = st.number_input(' ', key='tt4', step=1)
    
    thyroid_diagnosis = ''
    if st.button("Thyroid Test Result"):
        thyroid_prediction = models['thyroid'].predict([[age, sex, on_thyroxine, tsh, t3_measured, t3, tt4]])
        thyroid_diagnosis = "The person has Hypo-Thyroid disease" if thyroid_prediction[0] == 1 else "The person does not have Hypo-Thyroid disease"
        st.success(thyroid_diagnosis)
