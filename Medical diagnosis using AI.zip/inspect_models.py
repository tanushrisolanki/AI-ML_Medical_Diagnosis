import pickle
import os

model_paths = {
    'Diabetes': 'Models/diabetes_model.sav',
    'Heart Disease': 'Models/heart_disease_model.sav',
    'Parkinsons': 'Models/parkinsons_model.sav',
    'Lung Cancer': 'Models/lungs_disease_model.sav',
    'Thyroid': 'Models/Thyroid_model.sav'
}

for name, path in model_paths.items():
    if not os.path.exists(path):
        print(f"❌ File not found: {path}")
        continue
    try:
        with open(path, 'rb') as file:
            model = pickle.load(file)
            print(f"✅ Successfully loaded {name} model.")
            print(f"Model type: {type(model)}")
            print(model)
            print('-' * 50)
    except Exception as e:
        print(f"❌ Error loading {name}: {e}")

